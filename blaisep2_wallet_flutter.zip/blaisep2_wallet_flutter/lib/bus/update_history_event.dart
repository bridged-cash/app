
import 'package:event_taxi/event_taxi.dart';

class UpdateHistoryEvent implements Event {
}