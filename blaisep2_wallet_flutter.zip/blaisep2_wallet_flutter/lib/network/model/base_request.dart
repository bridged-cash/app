abstract class BaseRequest {
  Map<String, dynamic> toJson();
}