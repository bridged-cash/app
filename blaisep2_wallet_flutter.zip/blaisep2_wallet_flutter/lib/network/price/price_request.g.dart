// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'price_request.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

PriceRequest _$PriceRequestFromJson(Map<String, dynamic> json) {
  return PriceRequest(
    action: json['action'] as String,
  );
}

Map<String, dynamic> _$PriceRequestToJson(PriceRequest instance) =>
    <String, dynamic>{
      'action': instance.action,
    };
